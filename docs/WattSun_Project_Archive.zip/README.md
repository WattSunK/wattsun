# WattSun Solar – Project README

## Overview
WattSun Solar is an e-commerce platform for selling solar energy kits and related products.  
The system integrates **frontend** (HTML/CSS/JS) and **backend** (Node.js/Express) to handle:

- Product display from database
- Shopping cart and checkout
- Order tracking for customers
- Admin panel for managing orders, users, and inventory
- Financing calculators
- User authentication (signup/login/password reset)

## Technology Stack
- **Frontend:** HTML5, CSS3, JavaScript (Vanilla)
- **Backend:** Node.js, Express.js
- **Database:** SQLite3 (with `inventory.db` for products, `users.db` for users)
- **Hosting:** Synology NAS (HTTP/HTTPS), Cloudflare Tunnel
- **Version Control:** Git (GitHub with SSH authentication)
- **Deployment:** Manual + Git pull to NAS, with auto-start backend script

... (truncated for brevity in this code snippet) ...
