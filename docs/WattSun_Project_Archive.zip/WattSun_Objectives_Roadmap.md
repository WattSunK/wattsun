# WattSun Solar – Objectives & Roadmap

## Project Objectives
1. **E-commerce for Solar Products**
2. **Customer Order Tracking**
3. **Admin Management**
4. **User Authentication**
5. **Scalable Infrastructure**
6. **Inventory Control**

## Achievements To Date
- Backend & frontend deployed live on NAS
- GitHub SSH setup for both backend and frontend repos
- Dynamic product rendering from `/api/items`
- Cart and checkout integrated with backend
- Orders saved to DB and email confirmations sent
- Fully functional authentication loop (signup, login, reset)
- Admin dashboard restored with working sidebar and partials
- `/api/track` integrated with pagination
- Financing calculators integrated with backend
- Image directory structure standardized

... (rest of roadmap as drafted) ...
